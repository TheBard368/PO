package Wybory;

import java.util.ArrayList;

public abstract class Wyborca extends Osoba{
	protected Kandydat glos;
	
	public Wyborca(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy) {
		super(imie, nazwisko, okreg, cechy);
		
	}
	
	public int sumaWazona(ArrayList<Integer> lista) {
		int suma=0;
		for(int i=0; i<cechy.getCechy().size(); i++) {
			suma+=cechy.getCechy().get(i)*lista.get(i);
		}
		return suma;
	}
	
	public int symulujUpdate(ArrayList<Integer> lista, Kandydat kandydat)  {    //symuluje zmiane sumy wazonej dla danego kandydata
    	int suma=0, pom;
    	
        for(int i=0; i<cechy.getCechy().size(); i++) {
        	pom=(cechy.getCechy().get(i)+lista.get(i))*kandydat.getCechy().getCechy().get(i);
            if(pom>100)pom=100;
            else if(pom<-100)pom=-100;
            suma+=pom;
        }
        
        return suma;
    }
	
	public abstract void glosuj();
	
	public Kandydat getKandydat() {
		return glos;
	}
}
