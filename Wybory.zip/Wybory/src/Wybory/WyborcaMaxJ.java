package Wybory;

public class WyborcaMaxJ extends Wyborca {
	
	protected int cecha;

	public WyborcaMaxJ(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, int cecha) {
		super(imie, nazwisko, okreg, cechy);
		this.cecha=cecha;
	}

	@Override
	public void glosuj() {
		int max=-101, maxI=0, maxJ=-1;
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			if(max<okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				maxI=i;
				max=okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(okreg.getScalony()!=null)for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
			if(max<okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				maxJ=i;
				max=okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(maxJ>-1) {
			okreg.getScalony().getKandydaci().get(maxJ).zwiekszGlosy();
			glos=okreg.getScalony().getKandydaci().get(maxJ);
		}
		else {
			okreg.getKandydaci().get(maxI).zwiekszGlosy();
			glos=okreg.getKandydaci().get(maxI);
		}
	}

}
