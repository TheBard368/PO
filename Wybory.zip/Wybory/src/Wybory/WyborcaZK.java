package Wybory;

public class WyborcaZK extends Wyborca{
	
	private Kandydat kandydat;

	public WyborcaZK(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, Kandydat kandydat) {
		super(imie, nazwisko, okreg, cechy);
		this.kandydat=kandydat;
	}

	@Override
	public void glosuj() {
		kandydat.zwiekszGlosy();
	}

}
