package Wybory;

import java.util.ArrayList;

public class PartiaW extends Partia {					//Partia wlasna

	public PartiaW(String nazwa, int budzet, int numer) {
		super(nazwa, budzet, numer);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void wybierzDzialania(ArrayList<Dzialanie> dzialanie, ArrayList<OkregWyborczy> okreg) {
		// TODO Auto-generated method stub
		
	}			
}
