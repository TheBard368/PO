package Wybory;

public class WyborcaWP extends WyborcaW {
	
	private Partia partia;

	public WyborcaWP(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, Partia partia) {
		super(imie, nazwisko, okreg, cechy);
		this.partia=partia;
	}

	@Override
	public void glosuj() {
		int max=-2147483648, suma, maxI=0, maxJ=-1;
		int i, j;
		
		for(i=0; i<okreg.getKandydaci().size(); i++) {
			if(okreg.getKandydaci().get(i).getPartia()==partia) {
				suma=sumaWazona(okreg.getKandydaci().get(i).getCechy().getCechy());
				if(max<suma) {
					max=suma;
					maxI=i;
				}
			}
		}
		
		if(okreg.getScalony()!=null)for(j=0; j<okreg.getScalony().getKandydaci().size(); j++) {
			if(okreg.getScalony().getKandydaci().get(i).getPartia()==partia) {
				suma=sumaWazona(okreg.getScalony().getKandydaci().get(j).getCechy().getCechy());
				if(max<suma) {
					max=suma;
					maxJ=i;
				}
			}
		}
		
		if(maxJ>-1) {
			okreg.getScalony().getKandydaci().get(maxJ).zwiekszGlosy();
			glos=okreg.getScalony().getKandydaci().get(maxJ);
		}
		else {
			okreg.getKandydaci().get(maxI).zwiekszGlosy();
			glos=okreg.getKandydaci().get(maxI);
		}
	}

}
