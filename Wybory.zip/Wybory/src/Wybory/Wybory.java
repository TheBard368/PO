package Wybory;

import java.util.*;

public class Wybory {
	private int metoda, liczbaParti, liczbaDzialan, liczbaCech;                //liczba mandatow = liczbaWyborcow/10
	private ArrayList<Partia> listaParti;
	private ArrayList<Dzialanie> listaDzialan;
	
	public Wybory(int liczbaParti, int liczbaDzialan, int liczbaCech) {
		Random rand=new Random();
		
		metoda=rand.nextInt(3);
		this.liczbaParti=liczbaParti;
		this.liczbaDzialan=liczbaDzialan;
		this.liczbaCech=liczbaCech;
		listaParti=new ArrayList<Partia>();
		listaDzialan=new ArrayList<Dzialanie>();
	}
	
	public void dodajDzialanie(Dzialanie dzialanie) {                                              //Dzia�ania s� posortowane kosztem malej�co
		int i;
		
		for(i=0; i<listaDzialan.size() && dzialanie.getKoszt()<listaDzialan.get(i).getKoszt(); i++); 
		
		listaDzialan.add(i, dzialanie);
	}
	
	public void dodajPartie(String nazwa, char typ, int budzet, int numer) {
		Partia pom;
		
		switch(typ) {
		case 'R' :
			pom=new PartiaR(nazwa, budzet, numer);
			listaParti.add(pom);
			break;
		case 'Z' :
			pom=new PartiaZ(nazwa, budzet, numer);
			listaParti.add(pom);
			break;
		case 'S' :
			pom=new PartiaS(nazwa, budzet, numer);
			listaParti.add(pom);
			break;
		case 'W' :
			pom=new PartiaW(nazwa, budzet, numer);
			listaParti.add(pom);
			break;
		}
	}
	
	public void dajMandaty(OkregWyborczy okreg) {
		switch(metoda) {
			case 0 :
				metodaDHondta(okreg);
				break;
			case 1 :
				 metodaSainteLague(okreg);
				 break;
			case 2 :
				 metodaHareNiemeyera(okreg);
				 break;
		}
	}
	
	private void metodaDHondta(OkregWyborczy okreg) {
		float[] iloraz=new float[liczbaParti];
		int[] glosy=new int[liczbaParti];
		int[] ktoreDzielenie=new int [liczbaParti];
		float max;
		int maxI=0, a=okreg.getKandydaci().size();
		
		for(int i=0; i<liczbaParti; i++) {
			glosy[i]=0;
			ktoreDzielenie[i]=2;
		}
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			glosy[okreg.getKandydaci().get(i).getPartia().getNumer()]++;
		}
		if(okreg.getScalony()!=null) {
			a+=okreg.getScalony().getKandydaci().size();
			for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
				glosy[okreg.getScalony().getKandydaci().get(i).getPartia().getNumer()]++;
			}
		}
		for(int i=0; i<liczbaParti; i++) {
			iloraz[i]=glosy[i];
		}
		
		for(int i=0; i<a; i++) {
			max=0;
			for(int j=0; j<liczbaParti; j++) {
				if(iloraz[j]>max) {
					max=iloraz[j];
					maxI=j;
				}
			}
			listaParti.get(maxI).zwiekszMandaty();
			iloraz[maxI]=Math.floorDiv(glosy[maxI], ktoreDzielenie[maxI]);
			ktoreDzielenie[maxI]++;
		}
		
	}
	private void metodaSainteLague(OkregWyborczy okreg) {
		float[] iloraz=new float[liczbaParti];
		int[] glosy=new int[liczbaParti];
		int[] ktoreDzielenie=new int [liczbaParti];
		float max;
		int maxI=0, a=okreg.getKandydaci().size();
		
		for(int i=0; i<liczbaParti; i++) {
			glosy[i]=0;
			ktoreDzielenie[i]=3;
		}
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			glosy[okreg.getKandydaci().get(i).getPartia().getNumer()]++;
		}
		if(okreg.getScalony()!=null) {
			a+=okreg.getScalony().getKandydaci().size();
			for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
				glosy[okreg.getScalony().getKandydaci().get(i).getPartia().getNumer()]++;
			}
		}
		for(int i=0; i<liczbaParti; i++) {
			iloraz[i]=glosy[i];
		}
		
		for(int i=0; i<a; i++) {
			max=0;
			for(int j=0; j<liczbaParti; j++) {
				if(iloraz[j]>max) {
					max=iloraz[j];
					maxI=j;
				}
			}
			listaParti.get(maxI).zwiekszMandaty();
			iloraz[maxI]=Math.floorDiv(glosy[maxI], ktoreDzielenie[maxI]);
			ktoreDzielenie[maxI]+=2;
		}
	}
	private void metodaHareNiemeyera(OkregWyborczy okreg) {
		int[] glosy=new int[liczbaParti];
		int pom, pozostaleMandaty=okreg.getKandydaci().size(), maxI=0;
		float max;
		float [] reszty=new float[liczbaParti];
		
		for(int i=0; i<liczbaParti; i++) {
			glosy[i]=0;
		}
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			glosy[okreg.getKandydaci().get(i).getPartia().getNumer()]++;
		}
		if(okreg.getScalony()!=null) {
			pozostaleMandaty+=okreg.getScalony().getKandydaci().size();
			for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
				glosy[okreg.getScalony().getKandydaci().get(i).getPartia().getNumer()]++;
			}
		}
		
		for(int i=0; i<liczbaParti; i++) {
			pom=Math.floorDiv(glosy[i], 10);
			listaParti.get(i).zwiekszMandaty(pom);
			reszty[i]=glosy[i]/10-pom;
			pozostaleMandaty-=pom;
		}
		
		for(int i=0; i<pozostaleMandaty; i++) {
			max=0;
			for(int j=i; j<liczbaParti; j++) {
				if(reszty[j]>max) {
					max=reszty[j];
					maxI=j;
				}
			}
			listaParti.get(maxI).zwiekszMandaty();
		}
	}
	
	public int getLiczbaParti() {
		return liczbaParti;
	}
	public int getLiczbaDzialan() {
		return liczbaDzialan;
	}
	public int getLiczbaCech() {
		return liczbaCech;
	}
	
	
	
}
