package Wybory;

public class WyborcaMinJ extends Wyborca {

	protected int cecha;
	
	public WyborcaMinJ(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, int cecha) {
		super(imie, nazwisko, okreg, cechy);
		this.cecha=cecha;
	}

	@Override
	public void glosuj() {
		int min=101, minI=0, minJ=-1;
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			if(min>okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				minI=i;
				min=okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(okreg.getScalony()!=null)for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
			if(min<okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				minJ=i;
				min=okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(minJ>-1) {
			okreg.getScalony().getKandydaci().get(minJ).zwiekszGlosy();
			glos=okreg.getScalony().getKandydaci().get(minJ);
		}
		else {
			okreg.getKandydaci().get(minI).zwiekszGlosy();
			glos=okreg.getKandydaci().get(minI);
		}
		
	}

}
