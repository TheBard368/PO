package Wybory;

import java.util.*;

public class PartiaZ extends Partia {

	public PartiaZ(String nazwa, int budzet, int numer) {
		super(nazwa, budzet, numer);
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public void wybierzDzialania(ArrayList<Dzialanie> dzialanie, ArrayList<OkregWyborczy> okreg) {
		Random rand=new Random();
		int max, suma, maxK;
		OkregWyborczy pom;
		Dzialanie pom2;
		
		
		while(budzet-dzialanie.get(dzialanie.size()-1).getKoszt()>0) {
			pom=okreg.get(rand.nextInt(okreg.size()));
			suma=0;
			max=-2147483648;                            //minimalny int
			maxK=0;
			for(int k=0; k<dzialanie.size(); k++) {
				pom2=dzialanie.get(k);
				for(int i=0; i<pom.getWyborca().size(); i++) {
					for(int j=0; j<pom.getKandydaci().size(); j++) {
						suma+=pom.getWyborca().get(i).symulujUpdate(pom2.getRezultat(), pom.getKandydaci().get(j));
					}
				}
				if(pom.getScalony()!=null)for(int i=0; i<pom.getScalony().getWyborca().size(); i++) {
					for(int j=0; j<pom.getScalony().getKandydaci().size(); j++) {
						suma+=pom.getScalony().getWyborca().get(i).symulujUpdate(pom2.getRezultat(), pom.getScalony().getKandydaci().get(j));
					}
				}
				if(max<suma && budzet-dzialanie.get(k).getKoszt()>0) {
					max=suma;
					maxK=k;
				}
			}
			
			wykonajDzialanie(dzialanie.get(maxK), pom);
		}
		
	}

}
