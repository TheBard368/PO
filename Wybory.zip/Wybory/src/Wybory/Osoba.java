package Wybory;

public abstract class Osoba {
	protected String imie, nazwisko;
	protected OkregWyborczy okreg;
	protected Cechy cechy;
	
	public Osoba(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy) {
		this.imie=imie;
		this.nazwisko=nazwisko;
		this.okreg=okreg;
		this.cechy=cechy;
	}
	
	public OkregWyborczy getOkreg() {
		return okreg;
	}

	public String getNazwisko() {
		return nazwisko;
	}

	public Cechy getCechy() {
		return cechy;
	}
	
}
