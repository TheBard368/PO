package Wybory;

import java.util.*;

public class PartiaS extends Partia {

	public PartiaS(String nazwa, int budzet, int numer) {
		super(nazwa, budzet, numer);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void wybierzDzialania(ArrayList<Dzialanie> dzialanie, ArrayList<OkregWyborczy> okreg) {
		Random rand=new Random();
		
		while(budzet-dzialanie.get(dzialanie.size()-1).getKoszt()>0) 
			wykonajDzialanie(dzialanie.get(dzialanie.size()-1), okreg.get(rand.nextInt(okreg.size())));
		
		
	}

}
