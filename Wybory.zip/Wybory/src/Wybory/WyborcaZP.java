package Wybory;

import java.util.*;

public class WyborcaZP extends Wyborca {

	private Partia partia;
	public WyborcaZP(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, Partia partia) {
		super(imie, nazwisko, okreg, cechy);
		this.partia=partia; 
	}

	@Override
	public void glosuj() {
		Random rand=new Random();
		int pom;
		
		ArrayList<Kandydat> lista=new ArrayList<Kandydat>();
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			if(okreg.getKandydaci().get(i).getPartia()==partia)lista.add(okreg.getKandydaci().get(i));
		}
		if(okreg.getScalony()!=null)for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
			if(okreg.getScalony().getKandydaci().get(i).getPartia()==partia)lista.add(okreg.getScalony().getKandydaci().get(i));
		}
		
		pom=rand.nextInt(lista.size());
		lista.get(pom).zwiekszGlosy();
		glos=lista.get(pom);
	}

}
