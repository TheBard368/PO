package Wybory;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand=new Random();
		System.out.print(rand.nextInt(3));
	}

}
