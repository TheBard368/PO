package Wybory;

import java.util.*;

public class Cechy {
    private ArrayList<Integer> wartoscCechy;
    public Cechy(ArrayList<Integer> lista)  {
        this.wartoscCechy = new ArrayList<Integer>(lista);
    }
    public ArrayList<Integer> getCechy() {
        return wartoscCechy;
    }
    public void updateCechy(ArrayList<Integer> lista) {
        for(int i=0; i<wartoscCechy.size(); i++) {
            wartoscCechy.set(i, wartoscCechy.get(i) + lista.get(i));
            if(wartoscCechy.get(i)>100)wartoscCechy.set(i, 100);
            else if(wartoscCechy.get(i)<-100)wartoscCechy.set(i, -100);
        }
    }
    
}