package Wybory;

import java.util.*;

public abstract class Partia {                                                              //Partie zu�ywaj� sw�j ca�y bud�et po kolei
	protected String nazwa;
	protected int budzet;
	protected ArrayList<Kandydat> kandydaci;
	protected int mandaty;
	protected int numer;
	
	public Partia(String nazwa, int budzet, int numer) {
		this.nazwa=nazwa;
		this.budzet=budzet;
		kandydaci=new ArrayList<Kandydat>();
		mandaty=0;
		this.numer=numer;
	}
	
	public void dodajKandydata(Kandydat kandydat) {
		kandydaci.add(kandydat);
	}
	
	protected void wykonajDzialanie(Dzialanie dzialanie, OkregWyborczy okreg) {
		
		for(int j=0; j<okreg.getWyborca().size(); j++) {
			okreg.getWyborca().get(j).getCechy().updateCechy(dzialanie.getRezultat());
		}
		if(okreg.getScalony()!=null)for(int j=0; j<okreg.getScalony().getWyborca().size(); j++) {
			okreg.getScalony().getWyborca().get(j).getCechy().updateCechy(dzialanie.getRezultat());
		}
	}
	
	public abstract void wybierzDzialania(ArrayList<Dzialanie> dzialanie, ArrayList<OkregWyborczy> okreg) ;
	
	public String getNazwa() {
		return nazwa;
	}
	public int getMandaty() {
		return mandaty;
	}
	public void zwiekszMandaty() {
		mandaty++;
	}
	public int getNumer() {
		return numer;
	}
	public void zwiekszMandaty(int a) {
		mandaty+=a;
	}
}
