package Wybory;

import java.util.* ;

public class Dzialanie {
    private ArrayList<Integer> rezultat;
    private int koszt;
    
    public Dzialanie(ArrayList<Integer> lista)
    {
        this.rezultat = new ArrayList<Integer>(lista);
        this.koszt = 0;
        for(int i=0; i<this.rezultat.size();i++)
        {
            this.koszt += Math.abs(this.rezultat.get(i));
        }
    }
    public ArrayList<Integer> getRezultat()
    {
        return this.rezultat;
    }
    public int getKoszt()
    {
        return this.koszt;
    }
}