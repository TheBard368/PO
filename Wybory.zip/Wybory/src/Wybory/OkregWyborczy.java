package Wybory;

import java.util.*;

public class OkregWyborczy {
	private int numer;
	private ArrayList<Wyborca>  wyborcy;
	private ArrayList<Kandydat> kandydaci;
	private OkregWyborczy scalony;
	
	public OkregWyborczy(ArrayList<Kandydat> kandydaci, ArrayList<Wyborca> wyborcy) {
		scalony=null;
		this.wyborcy=wyborcy;
		this.kandydaci=kandydaci;
	}
	
	public static void scal(OkregWyborczy okreg1, OkregWyborczy okreg2) {
		okreg1.setScalony(okreg2);
		okreg2.setScalony(okreg1);
	}
	
	public ArrayList<Wyborca> getWyborca() {
		return wyborcy;
	}
	public int getNumer() {
		return numer;
	}
	public ArrayList<Kandydat> getKandydaci() {
		return kandydaci;
	}
	
	private void setScalony(OkregWyborczy okreg) {
		scalony=okreg;
	}
	
	public OkregWyborczy getScalony() {
		return scalony;
	}
	
}
