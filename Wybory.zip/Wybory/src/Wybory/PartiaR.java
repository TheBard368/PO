package Wybory;

import java.util.*;

public class PartiaR extends Partia {
	public PartiaR(String nazwa, int budzet, int numer) {
		super(nazwa, budzet, numer);
	}

	@Override
	public void wybierzDzialania(ArrayList<Dzialanie> dzialanie, ArrayList<OkregWyborczy> okreg) {
		Random rand=new Random();
		
		for(int i=0; i<dzialanie.size(); i++) {
			while(budzet-dzialanie.get(i).getKoszt()>0) 
				wykonajDzialanie(dzialanie.get(i), okreg.get(rand.nextInt(okreg.size())));
		}
		
	}
}
