package Wybory;

public class Kandydat extends Osoba{
	private Partia partia;
	private int nrNaLiscie;
	private int glosy;
	
	
	public Kandydat(String imie, String nazwisko, OkregWyborczy okreg, Partia partia, Cechy cechy, int nrNaLiscie) {
		super(imie, nazwisko, okreg, cechy);
		this.partia=partia;
		this.cechy=cechy;
		this.nrNaLiscie=nrNaLiscie;
		glosy=0;
	}
	
	public int getNumer() {
		return nrNaLiscie;
	}
	public Partia getPartia() {
		return partia;
	}
	public int getGlosy() {
		return glosy;
	}
	public void zwiekszGlosy() {
		glosy++;
	}
	
}
