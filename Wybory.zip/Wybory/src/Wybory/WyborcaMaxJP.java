package Wybory;

public class WyborcaMaxJP extends WyborcaMaxJ{
	private Partia partia;

	public WyborcaMaxJP(String imie, String nazwisko, OkregWyborczy okreg, Cechy cechy, int cecha, Partia partia) {
		super(imie, nazwisko, okreg, cechy, cecha);
		this.partia=partia;
	}
	
	@Override
	public void glosuj() {
		int max=-101, maxI=0, maxJ=-1;
		
		for(int i=0; i<okreg.getKandydaci().size(); i++) {
			if(okreg.getKandydaci().get(i).getPartia()==partia && max<okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				maxI=i;
				max=okreg.getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(okreg.getScalony()!=null)for(int i=0; i<okreg.getScalony().getKandydaci().size(); i++) {
			if(okreg.getScalony().getKandydaci().get(i).getPartia()==partia && max<okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha)) {
				maxJ=i;
				max=okreg.getScalony().getKandydaci().get(i).getCechy().getCechy().get(cecha);
			}
		}
		
		if(maxJ>-1) {
			okreg.getScalony().getKandydaci().get(maxJ).zwiekszGlosy();
			glos=okreg.getScalony().getKandydaci().get(maxJ);
		}
		else {
			okreg.getKandydaci().get(maxI).zwiekszGlosy();
			glos=okreg.getKandydaci().get(maxI);
		}
	}
}
